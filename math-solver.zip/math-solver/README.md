# Math Solver (Netlify + Gemini)

Files: index.html, netlify.toml, netlify/functions/solve.js

Deploy:
1. Push this folder to GitHub (or drag it into Netlify Deploy). Note: drag-and-drop works for functions only via Netlify CLI/Git; Git deploy is easiest.
2. Netlify > Site configuration > Environment variables > add GEMINI_API_KEY (get one at https://aistudio.google.com/apikey).
3. Redeploy. Local test: `npm i -g netlify-cli`, put GEMINI_API_KEY in a .env file, run `netlify dev`.

Model: gemini-3.8-flash by default. To switch, add an optional GEMINI_MODEL env var (e.g. gemini-3.5-flash-lite for cheaper/faster).
