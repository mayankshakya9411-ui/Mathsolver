// Netlify Function: POST /.netlify/functions/solve
// Reads the key from the GEMINI_API_KEY environment variable (never exposed to the browser).

// Latest Gemini Flash (GA). Override with an optional GEMINI_MODEL env var.
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

const SYSTEM = `You are a careful mathematics tutor and solver. Solve any math problem the user gives:
arithmetic, algebra, geometry, trigonometry, calculus, linear algebra, probability, statistics,
number theory, discrete math, differential equations, word problems, proofs and more.
Rules:
- Show clear numbered steps, then end with a line starting "**Answer:**".
- Write all math in LaTeX: inline as $...$ and display as $$...$$.
- Double-check arithmetic before answering. If the problem is ambiguous, state your assumption.
- If the input is not a math problem, politely say so.`;

const json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body),
});

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "Use POST." });

  const key = process.env.GEMINI_API_KEY;
  if (!key) return json(500, { error: "GEMINI_API_KEY is not set in Netlify environment variables." });

  let problem = "";
  try {
    problem = (JSON.parse(event.body || "{}").problem || "").trim();
  } catch {
    return json(400, { error: "Invalid JSON." });
  }
  if (!problem) return json(400, { error: "Enter a problem to solve." });
  if (problem.length > 4000) return json(400, { error: "Problem is too long (max 4000 characters)." });

  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM }] },
          contents: [{ role: "user", parts: [{ text: problem }] }],
          // Gemini 3.x: no temperature/top_p; use thinkingLevel (HIGH = best for math).
          generationConfig: { thinkingConfig: { thinkingLevel: "HIGH" } },
        }),
      }
    );
    const data = await res.json();
    if (!res.ok) return json(502, { error: data?.error?.message || "Gemini request failed." });

    const answer = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
    if (!answer) return json(502, { error: "No answer returned. Try rephrasing the problem." });
    return json(200, { answer });
  } catch (e) {
    return json(500, { error: "Server error: " + e.message });
  }
};
