# MathMind AI — Netlify डिप्लॉयमेंट गाइड

## प्रोजेक्ट संरचना
```
mathmind-ai/
├── netlify/
│   └── functions/
│       └── solve.js        ← सर्वरलेस बैकएंड (Express की जगह)
├── public/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── netlify.toml
├── package.json
├── .env.example
└── .gitignore
```

## Netlify पर डिप्लॉय कैसे करें

### विकल्प A — GitHub → Netlify (सुझाया गया तरीका)
1. इस फ़ोल्डर को एक नए GitHub रिपॉज़िटरी में पुश करें।
2. https://app.netlify.com पर जाएं → **Add new site** → **Import an existing project**।
3. अपना GitHub अकाउंट जोड़ें और रिपॉज़िटरी चुनें।
4. Build सेटिंग्स `netlify.toml` से अपने आप पढ़ी जाती हैं:
   - Publish directory: `public`
   - Functions directory: `netlify/functions`
   - Build command: (कोई नहीं चाहिए)
5. **Deploy site** पर क्लिक करें।

### विकल्प B — Drag and drop
1. पूरे प्रोजेक्ट फ़ोल्डर (`mathmind-ai/`) को https://app.netlify.com/drop पर खींचकर छोड़ें (केवल `public` फ़ोल्डर काफी नहीं है, क्योंकि function भी चाहिए)।
2. Netlify `netlify.toml` पढ़ता है और static site व function दोनों डिप्लॉय करता है।

### अपनी API key सेट करें (ज़रूरी — टेस्ट करने से पहले यह करें)
1. Netlify में: **Site configuration → Environment variables → Add a variable**
2. सेट करें:
   - **Key:** `API_KEY`
   - **Value:** `YOUR_REAL_API_KEY` (आपकी असली Anthropic/AI provider की key)
3. Save करें, फिर **Deploys → Trigger deploy → Deploy site** पर जाएं ताकि function को नया variable मिल सके।

> API key केवल `netlify/functions/solve.js` के अंदर `process.env.API_KEY` के ज़रिए पढ़ी जाती है। यह कभी भी `index.html`, `script.js` या किसी भी ऐसी फ़ाइल में नहीं जाती जिसे ब्राउज़र देख सके।

### डिप्लॉय के बाद टेस्ट करें
1. अपनी लाइव Netlify URL खोलें।
2. कोई समस्या लिखें (जैसे: "x का मान ज्ञात करें: 2x + 5 = 17"), कक्षा/विषय/कठिनाई चुनें, फिर **समस्या हल करें** पर क्लिक करें।
3. फ्रंटएंड `/.netlify/functions/solve` को कॉल करता है (relative path — किसी भी Netlify डोमेन पर काम करता है, कोई localhost नहीं)।

### लोकल टेस्टिंग (वैकल्पिक, Netlify के अपने dev server से — Express नहीं)
```bash
npm install -g netlify-cli
netlify dev
```
यह static site **और** function दोनों को लोकल रूप से उसी `/.netlify/functions/solve` पथ पर चलाता है, ताकि व्यवहार बिल्कुल production जैसा हो।

## ध्यान देने योग्य बातें
- Production में कोई `npm start` / Express सर्वर इस्तेमाल या ज़रूरी नहीं है।
- CORS को `solve.js` के अंदर response headers के ज़रिए संभाला गया है।
- ब्राउज़र को दिखाई जाने वाली सभी त्रुटियाँ सामान्य संदेश हैं ("AI सेवा अस्थायी रूप से उपलब्ध नहीं है...") — कोई internal error/stack trace कभी नहीं दिखाया जाता।
