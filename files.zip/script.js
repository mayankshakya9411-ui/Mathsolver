// public/script.js
// यह पूरी तरह ब्राउज़र में चलता है। इसमें कोई API key नहीं है।
// यह केवल Netlify Function से बात करता है: /.netlify/functions/solve
// (relative path — Netlify जो भी डोमेन देता है उस पर अपने आप काम करता है,
// कोई localhost / hardcoded URL नहीं है)

document.addEventListener("DOMContentLoaded", () => {
  // कक्षा 1–12 का dropdown भरें
  const classLevelSelect = document.getElementById("classLevel");
  for (let i = 1; i <= 12; i++) {
    const opt = document.createElement("option");
    opt.value = `Class ${i}`;
    opt.textContent = `कक्षा ${i}`;
    classLevelSelect.appendChild(opt);
  }

  const form = document.getElementById("solverForm");
  const solveBtn = document.getElementById("solveBtn");
  const btnText = document.getElementById("btnText");
  const btnSpinner = document.getElementById("btnSpinner");
  const errorBox = document.getElementById("errorBox");
  const resultCard = document.getElementById("resultCard");
  const resultMeta = document.getElementById("resultMeta");
  const resultText = document.getElementById("resultText");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const problem = document.getElementById("problem").value.trim();
    const classLevel = document.getElementById("classLevel").value;
    const topic = document.getElementById("topic").value;
    const difficulty = document.getElementById("difficulty").value;

    if (!problem) {
      showError("कृपया पहले कोई गणित की समस्या लिखें।");
      return;
    }

    setLoading(true);
    hideError();
    resultCard.classList.add("hidden");

    try {
      const response = await fetch("/.netlify/functions/solve", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ problem, classLevel, topic, difficulty }),
      });

      // स्टेटस चाहे जो भी हो, JSON पार्स करने की कोशिश करें ताकि सर्वर का
      // दिया हुआ त्रुटि संदेश (जैसे "AI सेवा अस्थायी रूप से उपलब्ध नहीं है") दिखा सकें
      let data;
      try {
        data = await response.json();
      } catch {
        data = null;
      }

      if (!response.ok || !data || !data.success) {
        const message =
          (data && data.error) ||
          "AI सेवा अस्थायी रूप से उपलब्ध नहीं है। कृपया फिर से प्रयास करें।";
        showError(message);
        return;
      }

      showResult(data);
    } catch (err) {
      // नेटवर्क विफलता, function तक न पहुँच पाना आदि। कभी भी err.stack न दिखाएं।
      showError("AI सेवा अस्थायी रूप से उपलब्ध नहीं है। कृपया फिर से प्रयास करें।");
    } finally {
      setLoading(false);
    }
  });

  function setLoading(isLoading) {
    solveBtn.disabled = isLoading;
    btnSpinner.classList.toggle("hidden", !isLoading);
    btnText.textContent = isLoading ? "हल किया जा रहा है..." : "समस्या हल करें";
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.classList.remove("hidden");
  }

  function hideError() {
    errorBox.classList.add("hidden");
    errorBox.textContent = "";
  }

  function showResult(data) {
    const metaParts = [];
    if (data.classLevel) metaParts.push(data.classLevel);
    if (data.topic) metaParts.push(data.topic);
    if (data.difficulty) metaParts.push(data.difficulty);
    resultMeta.textContent = metaParts.join(" · ");

    resultText.textContent = data.solution;
    resultCard.classList.remove("hidden");
    resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
});
