// netlify/functions/solve.js
//
// Netlify Function (serverless) — पुराने हमेशा-चलने वाले Express सर्वर की जगह।
// Netlify, netlify/functions/ में मौजूद हर फ़ाइल को अलग AWS Lambda function के
// रूप में डिप्लॉय करता है, जो इस पते पर उपलब्ध होता है: /.netlify/functions/solve
//
// API key केवल process.env.API_KEY से पढ़ी जाती है (Netlify डैशबोर्ड में सेट की जाती है),
// इसलिए यह कभी भी ब्राउज़र तक नहीं पहुँचती।

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

exports.handler = async function (event) {
  // ---- 1. CORS preflight संभालें ----
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 204,
      headers: CORS_HEADERS,
      body: "",
    };
  }

  // ---- 2. केवल POST की अनुमति दें ----
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "यह method स्वीकृत नहीं है। कृपया POST का उपयोग करें।" }),
    };
  }

  // ---- 3. Request body को सुरक्षित रूप से पार्स करें ----
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (err) {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Request body में गलत JSON है।" }),
    };
  }

  const { problem, classLevel, topic, difficulty } = payload;

  // ---- 4. इनपुट की जाँच करें ----
  if (!problem || typeof problem !== "string" || !problem.trim()) {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "कृपया हल करने के लिए कोई गणित की समस्या दर्ज करें।" }),
    };
  }

  // ---- 5. सुनिश्चित करें कि सर्वर पर API key मौजूद है ----
  const API_KEY = process.env.API_KEY;
  if (!API_KEY) {
    console.error("Netlify सेटिंग्स में API_KEY environment variable मौजूद नहीं है।");
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        error: "AI सेवा अस्थायी रूप से उपलब्ध नहीं है। कृपया फिर से प्रयास करें।",
      }),
    };
  }

  // ---- 6. AI मॉडल के लिए prompt तैयार करें (जवाब हिंदी में माँगा गया है) ----
  const systemPrompt =
    "आप MathMind AI हैं, कक्षा 1 से कक्षा 12 तक के छात्रों के लिए एक विशेषज्ञ गणित शिक्षक " +
    "(अंकगणित, बीजगणित, ज्यामिति, त्रिकोणमिति, कलन, सांख्यिकी और प्रायिकता को कवर करते हुए)। " +
    "हमेशा हिंदी भाषा में उत्तर दें और: " +
    "1) समस्या को स्पष्ट, क्रमांकित चरणों में हल करें। " +
    "2) दी गई कक्षा के स्तर के अनुसार सरल भाषा में सूत्र/अवधारणा समझाएं। " +
    "3) अंत में स्पष्ट रूप से अंतिम उत्तर दिखाएं, जिसकी शुरुआत 'अंतिम उत्तर:' से हो। " +
    "4) दिए गए विषय और कठिनाई स्तर के अनुरूप उत्तर दें। " +
    "व्याख्या मित्रवत, उत्साहजनक और छात्र के लिए समझने में आसान होनी चाहिए।";

  const userMessage =
    `कक्षा स्तर: ${classLevel || "निर्दिष्ट नहीं"}\n` +
    `विषय: ${topic || "निर्दिष्ट नहीं"}\n` +
    `कठिनाई स्तर: ${difficulty || "निर्दिष्ट नहीं"}\n\n` +
    `समस्या: ${problem}`;

  // ---- 7. AI API को कॉल करें (Anthropic Claude) ----
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1200,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      }),
    });

    if (!response.ok) {
      // upstream त्रुटि विवरण/stack trace कभी भी client को न दिखाएं
      console.error("AI API त्रुटि:", response.status, await response.text());
      return {
        statusCode: 502,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: "AI सेवा अस्थायी रूप से उपलब्ध नहीं है। कृपया फिर से प्रयास करें।",
        }),
      };
    }

    const data = await response.json();
    const solutionText =
      (data.content && data.content[0] && data.content[0].text) ||
      "माफ़ करें, इस बार समाधान तैयार नहीं हो सका। कृपया फिर से प्रयास करें।";

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({
        success: true,
        solution: solutionText,
        classLevel: classLevel || null,
        topic: topic || null,
        difficulty: difficulty || null,
      }),
    };
  } catch (err) {
    console.error("AI API कॉल करते समय अप्रत्याशित त्रुटि:", err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        error: "AI सेवा अस्थायी रूप से उपलब्ध नहीं है। कृपया फिर से प्रयास करें।",
      }),
    };
  }
};
